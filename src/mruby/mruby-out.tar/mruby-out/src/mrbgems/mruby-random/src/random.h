/*
** random.h - Random module
**
** See Copyright Notice in mruby.h
*/

#ifndef MRUBY_RANDOM_H
#define MRUBY_RANDOM_H

void mrb_mruby_random_gem_init(mrb_state *mrb);

#endif
